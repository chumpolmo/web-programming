<?php
$aName = $_POST['accName'];
// ...

echo "<h1>ข้อมูลบัญชีผู้ใช้</h1>";
echo "ชื่อ-สกุล: ".$aName."<br>";
// ...
?>