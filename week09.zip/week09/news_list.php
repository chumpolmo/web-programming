<?php
/***
 * Student Code: xxxxxxxxxxxx-x
 * Author: xxx xxx
 * Date: xxx xx, xxxx
 */
include "./libs/function.php";
include "./templates/header.php";
include "./templates/menu.php";

if(!isset($_SESSION['loggedIn']) || $_SESSION['loggedIn'] !== true){
  echo "กรุณาเข้าสู่ระบบ รอสักครู่!";
  header("Refresh: 3; url=login.php");
  die();
}

echo "<div class='w3-container'>";
echo "<h1 style='text-align: center;'>ข่าวประชาสัมพันธ์</h1>";

// Code here.


// For search data


echo "<div class='w3-right'>";
echo "<form action='{xxx}' method='GET'>";
echo "คำค้น : <input type='text' name='keyword'>";
echo "<input type='submit' name='sSubmit' value='ค้นหา' class='w3-blue'>";
echo "<input type='submit' name='cSubmit' value='เคลียร์' class='w3-red' onclick='location.href=\"./\"'>";
echo "</form>";
echo "</div>";

echo "รายการข่าว {xxx} ข่าว<br>";
echo "<table style='width:100%' class='w3-table-all'>";
echo "<tr class='w3-blue'><td style='width:10%;'>รหัสข่าว</td><td style='width:35%;'>หัวข้อ</td><td style='width:35%;'>รายละเอียด</td><td style='width:20%;'>ดำเนินการ</td></tr>";

// Code here.

    echo "<tr><td>".{xxx}."</td><td>".{xxx}."</td><td>".{xxx}."</td>";
    echo "<td><a href='news_view.php?act=VIEW&nid={xxx}' class='w3-button w3-green'>รายละเอียด</a> <a href='news_edit.php?act=EDIT&nid={xxx}' class='w3-button w3-orange'>แก้ไข</a> <a href='./src/action_page.php?act=DELETE&nid={xxx}' onclick='return confirm(\"กรุณายืนยันการลบข้อมูล?\");' class='w3-button w3-red'>ลบ</a></td>";
// Code here.

  echo "<tr><td colspan='4' class='w3-center'>--ไม่มีข้อมูลข่าว--</td></tr>";

// Free result memory

echo "<table><br>";
echo "<a href='index.php' class='w3-button w3-green'>กลับหน้าหลัก</a>";
echo "</div>";

// Close the connection

include "./templates/footer.php";
?>