<?php
/***
  * Source : https://www.lazada.co.th/
  */
$iotDevices = array(
  array(
    "iotId" => 1,
    "iotTitle" => "สมาร์ทรีโมทคอนโทรลโดย Ewelink APP",
    "iotDesc" => "สมาร์ทรีโมทคอนโทรลโดย Ewelink APP สำหรับ Smart Home 63A DIN Rail WIFI Circuit Breaker Switch TONGOU",
    "iotPhoto" => "./photos/1.png",
    "iotPrice" => "649",
    "iotStatus" => true
  ),
  array(
    "iotId" => 2,
    "iotTitle" => "Smart Human Body Sensor",
    "iotDesc" => "Tuya ZigBee 3.0 PIR Smart Human Body Sensor เซ็นเซอร์ประตูหน้าต่างอุณหภูมิและความชื้น Wireless Motion Detector Security Alarm System สำหรับ Alexa Goo Gle Home",
    "iotPhoto" => "./photos/2.png",
    "iotPrice" => "209",
    "iotStatus" => false
  ),
  array(
    "iotId" => 3,
    "iotTitle" => "Ewelink แป้นสวิตช์ Wi-Fi",
    "iotDesc" => "Ewelink แป้นสวิตช์ Wi-Fi เปิดปิด ตั้งเวลาผ่านแอปและรีโมท 433MHz รองรับ Google Home/Alexa Smart Wall Touch Switch Wi-Fi RF433Mhz",
    "iotPhoto" => "./photos/3.png",
    "iotPrice" => "479",
    "iotStatus" => true
  ),
  array(
    "iotId" => 4,
    "iotTitle" => "Tuya Wi-Fi Zigbee Smart Air Box",
    "iotDesc" => "Tuya Wi-Fi Zigbee Smart Air Box เซ็นเซอร์ตรวจจับแก๊สฟอร์มัลดีไฮด์, VOC, CO2, อุณหภูมิและความชื้น",
    "iotPhoto" => "./photos/4.png",
    "iotPrice" => "479",
    "iotStatus" => true
  )
);

// Code here.

?>