LM02
--
กำหนดให้ดำเนินการ config ค่า environment สำหรับการพัฒนาแอปพลิเคชัน ดังนี้
$ cd LM02_xxxxxxxxxxxx-x
$ composer update
หรือ ในกรณีที่มีปัญหากับ PHP version ให้เปลี่ยนมาใช้คำสั่งด้านล่างแทน
$ composer update --ignore-platform-req=php

--Good luck, sir.
20/02/2024
